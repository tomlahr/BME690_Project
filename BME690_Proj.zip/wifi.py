# wifi.py
# WLAN-Verbindung an/aus (Taste CTRL) und Server-Polling in der Hauptschleife.

import network
import socket
import time

import config
import state
import secrets
import web


def toggle_wifi():
    if state.wifi_active:
        if state.server:
            state.server.close()

        state.server = None
        state.wlan.disconnect()
        state.wlan.active(False)

        state.wifi_active = False
        state.ip = None
        print("WLAN deaktiviert")
        return

    state.wlan = network.WLAN(network.STA_IF)
    state.wlan.active(True)
    state.wlan.config(pm=config.WIFI_PM)
    state.wlan.config(hostname=config.WIFI_HOSTNAME)
    state.wlan.connect(secrets.WIFI_SSID, secrets.WIFI_PASSWORD)

    for _ in range(20):
        if state.wlan.isconnected():
            state.ip = state.wlan.ifconfig()[0]
            state.wifi_active = True

            state.server = socket.socket()
            state.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            state.server.bind(("", 80))
            state.server.listen(3)
            state.server.setblocking(False)

            print("Webserver: http://" + state.ip)
            return

        time.sleep_ms(500)

    state.wlan.active(False)
    state.ip = None
    state.wifi_active = False
    print("WLAN-Verbindung fehlgeschlagen")


def poll_server():
    if state.server is None:
        return

    try:
        conn, _ = state.server.accept()
        web.handle_request(conn)
    except OSError:
        pass
