# secrets.py
# WLAN-Zugangsdaten. Diese Datei NICHT teilen oder committen.
# Falls du schon eine eigene secrets.py auf dem Pico hast: nicht ueberschreiben,
# diese Datei ist nur ein Platzhalter fuers Gesamtpaket.

WIFI_SSID = "DEIN_WLAN"
WIFI_PASSWORD = "DEIN_PASSWORT"
