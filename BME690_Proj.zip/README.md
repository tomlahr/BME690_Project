# PicoBME690 - Modulare Struktur

## Dateien -> Pico
Alle zehn Dateien flach ins Wurzelverzeichnis kopieren, keine Unterordner:

    config.py
    secrets.py   (nicht im Paket - deine eigene Datei)
    colors.py
    state.py
    history.py
    sensors.py
    display.py
    web.py
    wifi.py
    main.py

**Falls du schon eine eigene `secrets.py` auf dem Pico hast: nicht mit der
hier beigelegten Platzhalter-Version ueberschreiben.**

## Paket 2 (2026-09-26) - aendert Messwerte
Geaendert: `iaq.py` (neu), `config.py`, `main.py`, `sensors.py`, `state.py`,
`web.py`. Einsatz: Innengeraet mit Display (Flur).
- Gemeinsames IAQ-Modul `iaq.py` (identisch in beiden Projekten):
  Zerfall nach Zeit (Halbwertszeit 6 h) statt pro Messung; Mindestspanne
  als Verhaeltnis hi/lo >= 2,0 - gleichbleibende Luft zeigt "gut" statt
  "kalibriert..."; 20 min Aufwaermphase nach dem Start (kalter Heizer
  verdarb frueher die Baseline); Baseline auf Flash (iaq_baseline.txt,
  alle 5 min). Simulation: 4 h konstante Luft -> 1 Labelwechsel (vorher
  rund 2.200/h beim BME690), Gas -20 % -> maessig, -60 % -> sehr schlecht.
- Messtakt 3 s statt 1 s (weniger Heizerwaerme, ruhigere Feuchte).
  ACHTUNG: aendert die Eigenerwaermung -> Temperatur-Offset am neuen
  Standort neu abgleichen (bis dahin liest das Geraet etwas zu niedrig).
- Diagramme mit Mindestskala (Temp 1 C, Feuchte 4 %, Druck 2 hPa) - keine
  Rechteck-Kurven mehr durch aufgeblasene 0,1-C-Spruenge.
- Gaswiderstand-Karte zeigt jetzt echtes Min/Max seit Start (vorher die
  zerfallende IAQ-Huellkurve). GAS_DECAY entfaellt.
- Diagramme zeigen die vollen 3 h (vorher nur die letzte Stunde, Fehler
  durch values[-60:]).
- Web-Dashboard mit Umlauten und "°C". Das LCD bleibt ASCII, weil die
  eingebaute framebuf-Schrift keine Umlaute kennt.

## WLAN-Autostart (2026-09-25)
Geaendert: `config.py`, `main.py`. Neue, zunaechst auskommentierte Zeile
`# WIFI_AUTOSTART = True` in config.py. Einkommentiert schaltet der BME690
das WLAN beim Start selbst ein (fuer das Balkon-Gehaeuse ohne Tastenzugang).

## WLAN-Angleich (2026-09-25)
Geaendert: `wifi.py` (Meldung, falls der Laendercode nicht greift),
`web.py` (Fusszeile "Laufzeit" statt irrefuehrend "Online" - der Wert war
schon immer die Zeit seit dem Start). Das Enviro+ nutzt jetzt dasselbe
WLAN-Verhalten. Router-Zeitschaltung 25.09. (8,5 h ohne WLAN): BME690
verband sich danach selbststaendig neu.
Hinweis: Ohne WLAN-Verbindung laeuft der Funkchip kuehler, die Temperatur
liegt dann gut 1 C zu niedrig (Offset gilt fuer den verbundenen Zustand).

## WLAN-Fix (2026-09-24)
Geaendert: `wifi.py`, `state.py`, `display.py`, `config.py` (neu: `WIFI_RESET_AFTER`).
- Anlass: Pico hing nach dem Start dauerhaft in "WLAN: verbinde...", ohne Meldung.
- Jeder Fehlversuch meldet jetzt den Funkchip-Status in der REPL, die
  System-Seite zeigt ihn als Kurztext statt "LINK?":
  AUTH = falsches Passwort, NOAP = Netz nicht gefunden, FAIL = abgelehnt,
  JOIN = verbindet noch, NOIP = keine IP per DHCP, IDLE = kein Versuch.
- Vor jedem neuen Versuch trennt der Code die alte Verbindung.
- Nach 3 Fehlversuchen (ca. 45 s) schaltet er die Schnittstelle komplett
  aus und wieder an (entspricht zweimal CTRL). Blockiert dabei ca. 0,2 s.
- Beim Start raeumt er einen haengengebliebenen Chip-Zustand ab.

## Kalibrierpaket (2026-09-24) - aendert Temperatur und Feuchte
Geaendert: `config.py`, `sensors.py` (restliche Dateien unveraendert).
- `TEMP_OFFSET` -3.4 -> -3.8, nach Nachkontrolle (2x -0.6 C) endgueltig -3.2.
- Feuchte: statt `HUMIDITY_OFFSET = 18` (additiv) jetzt Magnus-Umrechnung
  von der Sensor- auf die korrigierte Temperatur plus `HUMIDITY_TRIM = 7.0`.
  Der Trim ist vorlaeufig additiv; bei deutlich anderer Raumfeuchte
  (Heizperiode) pruefen, ob ein Faktor besser passt.
- Grundlage: drei Vergleichspunkte gegen SwitchBot und Wandsensor
  (23.09. 17:22 und 20:37, 24.09. vormittags).

## Paket 1 (2026-09-23) - keine Aenderung an Messwerten

1. **WLAN-Wiederverbindung.** `wifi.py` ist jetzt ein nicht blockierender
   Zustandsautomat. CTRL kehrt sofort zurueck, `wifi.poll()` baut die
   Verbindung in der Hauptschleife auf. Faellt der Link weg (Router-
   Neustart), schliesst poll() den verwaisten Server-Socket, verbindet alle
   15 s neu und oeffnet danach einen frischen Socket. Bei IP-Wechsel ohne
   Linkverlust ebenfalls neuer Socket.
2. **Laendercode.** `WIFI_COUNTRY` aus `secrets.py` (Rueckfallwert "DE" aus
   `config.py`), gesetzt VOR `wlan.active(True)`.
3. **Tasten blockieren nicht mehr.** Flankenerkennung statt Warteschleife -
   eine gehaltene Taste friert Sensor, Display und Webserver nicht mehr ein.
4. **Web:** Feuchtetrend zeigt "%" statt "%%"; der Drucktrend im JSON nutzt
   dieselbe Ausgleichsgerade wie `pressure_trend()`; `_drain()` vor dem
   Schliessen verhindert ERR_CONNECTION_RESET bei grossen Anfragen.

`secrets.py` liegt diesem Paket NICHT bei - deine vorhandene Datei behalten
(optional um `WIFI_COUNTRY = "DE"` ergaenzen).

## Aeltere Aenderungen (vor Paket 1)

1. **Modulare Aufteilung** - siehe Tabelle unten. Verhalten ist unveraendert,
   nur ueber mehrere Dateien verteilt.
2. **Selbsttest um T/P/H erweitert.** Bisher pruefte `update_selftest()` nur
   Heizerstabilitaet + Gaswert-Gueltigkeit + Gaswiderstand-Plausibilitaet.
   Jetzt zusaetzlich: Temperatur, Druck und Feuchte muessen in einer
   plausiblen Spanne liegen (siehe `config.py`, `TEMP_MIN_C` etc.) - nach
   dem Vorbild von Boschs eigenem `analyze_sensor_data()` in `bme69x.c`.
   **Wichtig:** Diese Grenzen sind selbst gewaehlte, grosszuegige
   Plausibilitaetswerte ("Sensor komplett kaputt/getrennt erkennen"),
   NICHT Boschs exakte interne Konstanten - die stehen in `bme69x_defs.h`,
   die mir nicht vorliegt.
3. **Druckkorrektur.** `config.PRESSURE_OFFSET = 1.0` (DWD-Vergleich:
   BME690 zeigte 1012 hPa bei 1013 hPa Referenz), angewendet in
   `sensors.update_sensor()` direkt auf den fertigen hPa-Wert.
4. **Bildschirmschoner.** Nach `config.SCREENSAVER_IDLE_MS` (Standard: 5 Min)
   ohne Tastendruck dimmt das Display auf `SCREENSAVER_BRIGHTNESS` (~20%)
   und zeigt einen langsam wandernden, hin- und herlaufenden horizontalen
   Strich (`display.draw_screensaver()`) - ein Lebenszeichen statt komplett
   dunklem Schirm. **Jede** Taste weckt auf; der erste Tastendruck nach dem
   Aufwachen loest NUR das Aufwachen aus, seine eigentliche Funktion (Seite
   wechseln, Helligkeit aendern, WLAN togglen) wird bei diesem einen Druck
   ignoriert - verhindert versehentliche Aktionen beim blinden Hinschauen.
   Sensor-Lesen, Verlaufsaufzeichnung und Webserver laufen im
   Bildschirmschoner-Modus unveraendert weiter, nur Zeichnen und
   Backlight-Helligkeit sind betroffen.

## Architektur-Loesung: state.py

Dein Original hielt alle Messwerte als globale Variablen in einer Datei -
das geht nur, weil dort auch alle Funktionen sitzen, die per `global`
draufzugreifen. Ueber mehrere Dateien verteilt, gibt's kein gemeinsames
"global" mehr. Loesung: `state.py` haelt nur die gemeinsamen Werte
(`last_temp`, `min_gas`, `wifi_active`, ...), alle anderen Module lesen/
schreiben direkt `state.last_temp = ...` statt `global last_temp` zu
deklarieren. Kein Verhaltensunterschied, nur die Art, wie der Zustand
zwischen Dateien geteilt wird.

## Zuordnung alt -> neu

| Aus der alten main.py                                    | Jetzt in       |
|------------------------------------------------------------|----------------|
| Konstanten (Pins, Offsets, Intervalle, MODE_NAMES)          | `config.py`    |
| Farbkonstanten                                              | `colors.py`    |
| Globale Messwerte/Zustand (`last_temp`, `wifi_active`, ...)  | `state.py`     |
| `record_history`, `delta_from_history`, `signed_value`, `uptime` | `history.py` |
| `update_sensor`, `update_selftest`, `selftest_text`, `internal_temp`, `iaq_relative`, `comfort_text`, `gas_status_text`, `pressure_trend`, `weather_trend` | `sensors.py` |
| `LCD_0inch96`, `draw`                                       | `display.py`   |
| `html_page`, `json_data`, `sparkline`, `iaq_overlay`, `chart_card`, `pressure_chart`, `gas_chart`, `send_all`, `send_response`, `handle_request` | `web.py` |
| `toggle_wifi`, `poll_server`                                | `wifi.py`      |
| Tasten, Initialisierung, Hauptschleife                      | `main.py`      |

## Verifiziert vor der Auslieferung
- Alle zehn Dateien einzeln mit `py_compile` auf Syntaxfehler geprueft.
- Ein Skript hat jede `modul.name`-Referenz (z.B. `state.last_temp`,
  `config.HEATER_TEMP`) gegen die tatsaechliche Definition im Zielmodul
  abgeglichen - keine Tippfehler oder fehlenden Namen gefunden.

**Was ich NICHT pruefen kann:** Echtes Verhalten auf der Hardware (Timing,
I2C, Speicherverbrauch). Der Code ist Zeile fuer Zeile aus deiner
bestaetigt funktionierenden main.py portiert, aber ein erster Testlauf auf
dem Pico bleibt trotzdem noetig.

## Bei Problemen
Falls beim ersten Start ein `ImportError` oder `AttributeError` auftaucht,
schick mir die genaue Fehlermeldung - die verrät sofort, welches Modul
betroffen ist.

# EOF 2026-09-26
