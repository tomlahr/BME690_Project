# history.py
# Verlaufsaufzeichnung und daraus abgeleitete Werte (Deltas, Laufzeit).

import time

import config
import state


def record_history():
    if state.last_temp is None:
        return

    state.history_temp.append(state.last_temp)
    state.history_hum.append(state.last_hum)
    state.history_pres.append(state.last_pres)
    state.history_gas.append(state.last_gas)

    if len(state.history_temp) > config.HISTORY_SIZE:
        state.history_temp.pop(0)
        state.history_hum.pop(0)
        state.history_pres.pop(0)
        state.history_gas.pop(0)


def delta_from_history(values, minutes):
    if len(values) <= minutes:
        return None

    return values[-1] - values[-1 - minutes]


def signed_value(value, decimals=1, unit=""):
    if value is None:
        return "--"

    prefix = "+" if value > 0 else ""
    return (("%s%%.%df" % (prefix, decimals)) % value) + unit


def uptime():
    seconds = time.ticks_diff(time.ticks_ms(), state.boot_time) // 1000

    return "%02d:%02d:%02d" % (
        seconds // 3600,
        seconds % 3600 // 60,
        seconds % 60
    )
