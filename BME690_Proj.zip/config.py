# config.py
# Zentrale Konfiguration - Pins, Intervalle, Kalibrierwerte, Selbsttest-Grenzen.

# ── Display (SPI) ──────────────────────────────────────────
DISP_CS, DISP_RST, DISP_BL = 9, 12, 13
DISP_SCK, DISP_MOSI, DISP_DC = 10, 11, 8

# ── Sensor (I2C) ───────────────────────────────────────────
I2C_SDA, I2C_SCL = 4, 5
BME_ADDRESS = 0x76  # bestaetigt korrekt - der 0x77-Scan war vermutlich ein
                     # Artefakt der Verbindungsstoerung, die kurz danach zum
                     # kompletten Verbindungsabbruch fuehrte, keine echte
                     # Adressaenderung am Sensor

# ── Kalibrierung ───────────────────────────────────────────
# Werte aus den SwitchBot-Vergleichsmessungen, siehe Chat-Verlauf.
TEMP_OFFSET = -3.4
HUMIDITY_OFFSET = 18
GAS_DECAY = 0.999
# DWD-Vergleich (2026-09-xx): BME690 zeigte 1012 hPa bei 1013 hPa Referenz -> zu niedrig.
PRESSURE_OFFSET = 1.0

# ── Heizerprofil ───────────────────────────────────────────
HEATER_TEMP = 320
HEATER_DURATION_MS = 150

# ── Selbsttest-Naeherung ───────────────────────────────────
# Boschs eigener Selbsttest prueft u.a. den internen Heizstrom-Regelwert
# (idac) - der ist ueber diese Bibliothek nicht zugaenglich (bestaetigt per
# REPL: bme.read() liefert keine idac-Werte). Stattdessen: Heizerstabilitaet,
# Gaswert-Gueltigkeit, und Plausibilitaetsspannen fuer alle vier Messgroessen -
# nach dem Vorbild von Boschs eigenem analyze_sensor_data() in bme69x.c.
#
# WICHTIG: TEMP_MIN_C/TEMP_MAX_C/PRES_MIN_HPA/... sind GROSSZUEGIGE, selbst
# gewaehlte Plausibilitaetsgrenzen (z.B. "Zimmertemperatur, kein Vakuum") -
# NICHT Boschs exakte interne Konstanten (BME69X_MIN_TEMPERATURE etc.), die
# in bme69x_defs.h stehen und mir nicht vorliegen. Ziel ist "Sensor komplett
# kaputt/getrennt erkennen", nicht Boschs Werksgrenzen 1:1 nachzubilden.
SELFTEST_WINDOW = 5
GAS_MIN_KOHM = 0.5
GAS_MAX_KOHM = 5000.0
TEMP_MIN_C = -10.0
TEMP_MAX_C = 60.0
PRES_MIN_HPA = 900.0
PRES_MAX_HPA = 1100.0
HUM_MIN_PCT = 0.0
HUM_MAX_PCT = 100.0

# "Anklopfen": vergleicht die Steigung der juengsten 10 Minuten gegen die
# davor liegenden 20 Minuten (Luftdruck), um einen Umschwung frueher zu
# erkennen als im 30-Minuten-Gesamttrend. SWING_MINUTES_NEW/OLD und die
# Schwelle sind selbst gewaehlte Startwerte - noch nicht in der Praxis
# gegen echte Wetterwechsel kalibriert.
PRESSURE_SWING_MINUTES_NEW = 10
PRESSURE_SWING_MINUTES_OLD = 20
PRESSURE_SWING_THRESHOLD = 0.05  # hPa/Minute Unterschied, ab dem "auf"/"ab" gilt

# ── Takt ───────────────────────────────────────────────────
SENSOR_INTERVAL_MS = 1000
DISPLAY_INTERVAL_MS = 500
HISTORY_INTERVAL_MS = 60_000
HISTORY_SIZE = 181
LOOP_SLEEP_MS = 10

# ── Anzeige ────────────────────────────────────────────────
BRIGHTNESS_LEVELS = (300, 600, 1000)
MODE_NAMES = ("Klima", "Gas / IAQ", "Min / Max", "WLAN", "System")

# ── Bildschirmschoner ──────────────────────────────────────
SCREENSAVER_IDLE_MS = 5 * 60 * 1000   # 5 Minuten Inaktivitaet
SCREENSAVER_BRIGHTNESS = 200           # ~20% von 1000
SCREENSAVER_STEP_MS = 150              # Zeit pro Schritt
SCREENSAVER_STEP_PX = 3                # Pixel pro Schritt (+50% gegenueber vorher)
SCREENSAVER_BAR_W = 14                 # Breite des KITT-Scanner-Segments

# ── WLAN ───────────────────────────────────────────────────
WIFI_HOSTNAME = "PicoBME690Sensor"
WIFI_PM = 0xa11140  # Powersave aus, stabiler als Server
