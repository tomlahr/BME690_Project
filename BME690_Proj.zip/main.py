# main.py
# Bindet alle Module zusammen. Nur noch Tastenabfrage, Initialisierung und
# die Hauptschleife - die eigentliche Logik steckt in den anderen Dateien.

from machine import Pin
from pimoroni_i2c import PimoroniI2C
import gc
import time

import config
import state
import history
import sensors
import display
import wifi

# ── Tasten ─────────────────────────────────────────────────────
KEY_UP = Pin(2, Pin.IN, Pin.PULL_UP)
KEY_DOWN = Pin(18, Pin.IN, Pin.PULL_UP)
KEY_LEFT = Pin(16, Pin.IN, Pin.PULL_UP)
KEY_RIGHT = Pin(20, Pin.IN, Pin.PULL_UP)
KEY_CTRL = Pin(3, Pin.IN, Pin.PULL_UP)
KEY_A = Pin(15, Pin.IN, Pin.PULL_UP)
KEY_B = Pin(17, Pin.IN, Pin.PULL_UP)


def pressed(key):
    if key.value():
        return False

    time.sleep_ms(25)

    if key.value():
        return False

    while not key.value():
        time.sleep_ms(10)

    return True


# ── Initialisierung ─────────────────────────────────────────────
display.init()

i2c = PimoroniI2C(sda=config.I2C_SDA, scl=config.I2C_SCL)
sensors.init(i2c)

state.boot_time = time.ticks_ms()
state.min_mem_free = gc.mem_free()

# Starthelligkeit: 600
display.lcd.backlight(config.BRIGHTNESS_LEVELS[state.brightness_idx])

last_sensor = time.ticks_add(state.boot_time, -config.SENSOR_INTERVAL_MS)
last_display = time.ticks_add(state.boot_time, -config.DISPLAY_INTERVAL_MS)
last_history = time.ticks_add(state.boot_time, -config.HISTORY_INTERVAL_MS)

# Frueher sammeln statt erst im Notfall
gc.threshold(gc.mem_free() // 4 + gc.mem_alloc())

state.last_activity = state.boot_time

# ── Hauptschleife ───────────────────────────────────────────────
while True:
    any_key = False

    if pressed(KEY_A) or pressed(KEY_RIGHT):
        any_key = True
        if not state.screensaver_active:
            state.mode = (state.mode + 1) % len(config.MODE_NAMES)
            last_display = time.ticks_add(time.ticks_ms(), -config.DISPLAY_INTERVAL_MS)

    elif pressed(KEY_B) or pressed(KEY_LEFT):
        any_key = True
        if not state.screensaver_active:
            state.mode = (state.mode - 1) % len(config.MODE_NAMES)
            last_display = time.ticks_add(time.ticks_ms(), -config.DISPLAY_INTERVAL_MS)

    elif pressed(KEY_UP):
        any_key = True
        if not state.screensaver_active:
            state.brightness_idx = min(
                state.brightness_idx + 1,
                len(config.BRIGHTNESS_LEVELS) - 1
            )
            display.lcd.backlight(config.BRIGHTNESS_LEVELS[state.brightness_idx])

    elif pressed(KEY_DOWN):
        any_key = True
        if not state.screensaver_active:
            state.brightness_idx = max(state.brightness_idx - 1, 0)
            display.lcd.backlight(config.BRIGHTNESS_LEVELS[state.brightness_idx])

    elif pressed(KEY_CTRL):
        any_key = True
        if not state.screensaver_active:
            wifi.toggle_wifi()
            last_display = time.ticks_add(time.ticks_ms(), -config.DISPLAY_INTERVAL_MS)

    if any_key:
        state.last_activity = time.ticks_ms()
        if state.screensaver_active:
            state.screensaver_active = False
            display.lcd.backlight(config.BRIGHTNESS_LEVELS[state.brightness_idx])
            last_display = time.ticks_add(time.ticks_ms(), -config.DISPLAY_INTERVAL_MS)

    wifi.poll_server()

    now = time.ticks_ms()

    free = gc.mem_free()
    if free < state.min_mem_free:
        state.min_mem_free = free

    if time.ticks_diff(now, last_sensor) >= config.SENSOR_INTERVAL_MS:
        last_sensor = now
        sensors.update_sensor()
        sensors.update_selftest()

    if time.ticks_diff(now, last_history) >= config.HISTORY_INTERVAL_MS:
        last_history = now
        history.record_history()

    if not state.screensaver_active and time.ticks_diff(now, state.last_activity) >= config.SCREENSAVER_IDLE_MS:
        state.screensaver_active = True
        state.screensaver_x = 0
        state.screensaver_dir = 1
        display.lcd.backlight(config.SCREENSAVER_BRIGHTNESS)

    if state.screensaver_active:
        if time.ticks_diff(now, last_display) >= config.SCREENSAVER_STEP_MS:
            last_display = now
            state.screensaver_x += state.screensaver_dir * config.SCREENSAVER_STEP_PX
            if state.screensaver_x >= display.lcd.width - config.SCREENSAVER_BAR_W or state.screensaver_x <= 0:
                state.screensaver_dir = -state.screensaver_dir
            display.draw_screensaver()
    else:
        if time.ticks_diff(now, last_display) >= config.DISPLAY_INTERVAL_MS:
            last_display = now
            display.draw()

    time.sleep_ms(config.LOOP_SLEEP_MS)

# EOF - modular aufgeteilt aus main.py (2026-09-11, Auszuege K.I. generiert)
