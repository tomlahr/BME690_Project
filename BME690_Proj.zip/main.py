# main.py
# Bindet alle Module zusammen. Nur noch Tastenabfrage, Initialisierung und
# die Hauptschleife - die eigentliche Logik steckt in den anderen Dateien.

from machine import Pin
from pimoroni_i2c import PimoroniI2C
import gc
import time

import config
import state
import history
import sensors
import display
import wifi

# ── Tasten ─────────────────────────────────────────────────────
KEY_UP = Pin(2, Pin.IN, Pin.PULL_UP)
KEY_DOWN = Pin(18, Pin.IN, Pin.PULL_UP)
KEY_LEFT = Pin(16, Pin.IN, Pin.PULL_UP)
KEY_RIGHT = Pin(20, Pin.IN, Pin.PULL_UP)
KEY_CTRL = Pin(3, Pin.IN, Pin.PULL_UP)
KEY_A = Pin(15, Pin.IN, Pin.PULL_UP)
KEY_B = Pin(17, Pin.IN, Pin.PULL_UP)


def pressed(key):
    if key.value():
        return False

    time.sleep_ms(25)

    if key.value():
        return False

    while not key.value():
        time.sleep_ms(10)

    return True


# ── Initialisierung ─────────────────────────────────────────────
display.init()

i2c = PimoroniI2C(sda=config.I2C_SDA, scl=config.I2C_SCL)
sensors.init(i2c)

state.boot_time = time.ticks_ms()
state.min_mem_free = gc.mem_free()

# Starthelligkeit: 600
display.lcd.backlight(config.BRIGHTNESS_LEVELS[state.brightness_idx])

last_sensor = time.ticks_add(state.boot_time, -config.SENSOR_INTERVAL_MS)
last_display = time.ticks_add(state.boot_time, -config.DISPLAY_INTERVAL_MS)
last_history = time.ticks_add(state.boot_time, -config.HISTORY_INTERVAL_MS)

# Frueher sammeln statt erst im Notfall
gc.threshold(gc.mem_free() // 4 + gc.mem_alloc())

# ── Hauptschleife ───────────────────────────────────────────────
while True:
    if pressed(KEY_A) or pressed(KEY_RIGHT):
        state.mode = (state.mode + 1) % len(config.MODE_NAMES)
        last_display = time.ticks_add(time.ticks_ms(), -config.DISPLAY_INTERVAL_MS)

    elif pressed(KEY_B) or pressed(KEY_LEFT):
        state.mode = (state.mode - 1) % len(config.MODE_NAMES)
        last_display = time.ticks_add(time.ticks_ms(), -config.DISPLAY_INTERVAL_MS)

    elif pressed(KEY_UP):
        state.brightness_idx = min(
            state.brightness_idx + 1,
            len(config.BRIGHTNESS_LEVELS) - 1
        )
        display.lcd.backlight(config.BRIGHTNESS_LEVELS[state.brightness_idx])

    elif pressed(KEY_DOWN):
        state.brightness_idx = max(state.brightness_idx - 1, 0)
        display.lcd.backlight(config.BRIGHTNESS_LEVELS[state.brightness_idx])

    elif pressed(KEY_CTRL):
        wifi.toggle_wifi()
        last_display = time.ticks_add(time.ticks_ms(), -config.DISPLAY_INTERVAL_MS)

    wifi.poll_server()

    now = time.ticks_ms()

    free = gc.mem_free()
    if free < state.min_mem_free:
        state.min_mem_free = free

    if time.ticks_diff(now, last_sensor) >= config.SENSOR_INTERVAL_MS:
        last_sensor = now
        sensors.update_sensor()
        sensors.update_selftest()

    if time.ticks_diff(now, last_history) >= config.HISTORY_INTERVAL_MS:
        last_history = now
        history.record_history()

    if time.ticks_diff(now, last_display) >= config.DISPLAY_INTERVAL_MS:
        last_display = now
        display.draw()

    time.sleep_ms(config.LOOP_SLEEP_MS)

# EOF - modular aufgeteilt aus main.py (2026-09-11, Auszuege K.I. generiert)
